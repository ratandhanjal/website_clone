"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navLinks = [
  { name: "Grok", href: "/grok" },
  { name: "API", href: "/api" },
  { name: "Company", href: "/company" },
  { name: "Colossus", href: "/colossus" },
  { name: "Careers", href: "/careers" },
  { name: "News", href: "/news" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [scrolled]);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 flex items-center h-14 justify-between px-6 md:px-10 transition-all duration-300",
        scrolled ? "bg-black/80 backdrop-blur-sm" : "bg-transparent"
      )}
    >
      <div className="flex items-center">
        <Link href="/" className="mr-8">
          <span className="font-bold text-2xl text-white">x</span>
        </Link>
        <nav className="hidden md:flex space-x-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="text-sm text-white/80 hover:text-white transition-colors"
            >
              {link.name}
            </Link>
          ))}
        </nav>
      </div>

      <div>
        <Button asChild variant="outline" className="bg-white/10 border-none hover:bg-white/20 text-white text-sm">
          <a href="https://grok.com/?referrer=website" target="_blank" rel="noopener noreferrer">
            Try Grok
          </a>
        </Button>
      </div>
    </header>
  );
}
