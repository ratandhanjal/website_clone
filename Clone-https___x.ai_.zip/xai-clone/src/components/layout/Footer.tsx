"use client";

import Link from "next/link";
import { Separator } from "@/components/ui/separator";

const footerLinks = {
  tryGrokOn: [
    { name: "Web", href: "https://grok.com" },
    { name: "iOS", href: "https://apps.apple.com/app/apple-store/id6670324846?pt=126952307&ct=x.ai%20Direct%20Link&mt=8" },
    { name: "Android", href: "https://play.google.com/store/apps/details?id=ai.x.grok&hl=en" },
    { name: "Grok on X", href: "https://x.com/i/grok" },
  ],
  products: [
    { name: "Grok", href: "/grok" },
    { name: "API", href: "/api" },
  ],
  company: [
    { name: "Company", href: "/company" },
    { name: "Careers", href: "/careers" },
    { name: "Contact", href: "/contact" },
    { name: "News", href: "/news" },
  ],
  resources: [
    { name: "Status", href: "https://status.x.ai" },
    { name: "Privacy policy", href: "/privacy-policy" },
    { name: "Security", href: "/security" },
    { name: "Legal", href: "/legal" },
  ],
};

export default function Footer() {
  return (
    <footer className="w-full bg-black text-white py-16 relative">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-50"
        style={{
          backgroundImage: "url('https://ext.same-assets.com/292567494/3336218283.webp')",
          backgroundPosition: "center top",
          maxHeight: "150px"
        }}
      />

      <div className="container mx-auto px-6 md:px-10 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10">
          <div>
            <h3 className="text-white/60 text-sm font-semibold mb-4">Try Grok On</h3>
            <div className="flex flex-col space-y-2">
              {footerLinks.tryGrokOn.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-white hover:text-white/80 transition-colors text-sm"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-white/60 text-sm font-semibold mb-4">Products</h3>
            <div className="flex flex-col space-y-2">
              {footerLinks.products.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-white hover:text-white/80 transition-colors text-sm"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-white/60 text-sm font-semibold mb-4">Company</h3>
            <div className="flex flex-col space-y-2">
              {footerLinks.company.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-white hover:text-white/80 transition-colors text-sm"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-white/60 text-sm font-semibold mb-4">Resources</h3>
            <div className="flex flex-col space-y-2">
              {footerLinks.resources.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-white hover:text-white/80 transition-colors text-sm"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
