"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Hero() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <section className="relative h-screen flex flex-col justify-center items-center px-4 overflow-hidden">
      {/* Orange glow effect */}
      <div className="orange-glow" />

      {/* Large Grok text in background */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none z-0">
        <h1 className="text-[20vw] font-bold text-transparent text-stroke opacity-10">Grok</h1>
      </div>

      {/* Content container */}
      <div className="relative z-10 text-center max-w-2xl mx-auto mt-24">
        {/* Search box */}
        <div className="relative w-full max-w-md mx-auto mb-8">
          <input
            type="text"
            placeholder="Ask Grok anything..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/10 backdrop-blur-sm border border-white/20 rounded-full py-3 px-6 pr-10 text-white placeholder:text-white/50 focus:outline-none focus:ring-1 focus:ring-white/30"
          />
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
            <span className="text-xs text-white">↵</span>
          </div>
        </div>

        {/* Description text */}
        <p className="text-white/80 text-sm max-w-md mx-auto mb-6">
          We are thrilled to unveil Grok 3, our most advanced model yet,
          blending superior reasoning with extensive pretraining knowledge.
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button asChild className="bg-white hover:bg-white/90 text-black">
            <a href="https://grok.com" target="_blank" rel="noopener noreferrer">
              Build with Grok
            </a>
          </Button>
          <Button asChild variant="outline" className="border-white/30 hover:bg-white/10">
            <Link href="/news/grok-3">
              Learn more
            </Link>
          </Button>
        </div>
      </div>

      {/* Down arrow */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 5V19M12 19L19 12M12 19L5 12" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
    </section>
  );
}
