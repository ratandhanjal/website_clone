"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Mission() {
  return (
    <section className="relative py-32 px-6 md:px-10 overflow-hidden" id="mission">
      {/* Orange glow effect */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-transparent to-[rgba(201,104,71,0.1)]"
        style={{
          maxWidth: "50%",
          left: "auto"
        }}
      />

      <div className="container mx-auto relative z-10">
        <div className="flex items-center mb-8">
          <div className="w-16 h-px bg-white/20 mr-4"></div>
          <span className="text-white/60 text-sm uppercase tracking-wider">Our Mission</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-5xl md:text-7xl font-bold mb-8 leading-tight">
              Understand<br />the Universe
            </h2>

            <Button asChild className="mt-4" variant="outline">
              <Link href="/careers">
                Join us
                <svg className="ml-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              </Link>
            </Button>
          </div>

          <div>
            <p className="text-white/80 text-lg leading-relaxed mb-6">
              AI's knowledge should be all-encompassing and as far-reaching as possible. We build AI specifically to advance human comprehension and capabilities.
            </p>

            <p className="text-white/80 text-lg leading-relaxed">
              We're moving toward a future where we will harness our cluster's full power to solve intractable problems. What's one seemingly impossible question you'd answer for humanity?
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
