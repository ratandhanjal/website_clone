"use client";

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";

const products = [
  {
    title: "Grok",
    description: "Grok is your cosmic guide, now accessible on grok.com, iOS, and Android. Explore the universe with AI.",
    link: "https://grok.com/?referrer=website",
    buttonText: "Use now",
    imageSrc: null
  },
  {
    title: "API",
    description: "Supercharge your applications with Grok's enhanced speed, precision, and multilingual capabilities.",
    link: "https://console.x.ai/",
    buttonText: "Build API",
    imageSrc: "https://ext.same-assets.com/292567494/1998606599.svg"
  },
  {
    title: "Developer Docs",
    description: "Learn how to quickly install Grok at the heart of your applications and explore guides covering common use cases.",
    link: "https://docs.x.ai/",
    buttonText: "Learn more",
    imageSrc: "https://ext.same-assets.com/292567494/2018733539.svg"
  }
];

export default function Products() {
  return (
    <section className="py-24 px-6 md:px-10" id="products">
      <div className="container mx-auto">
        <div className="flex items-center mb-12">
          <div className="w-16 h-px bg-white/20 mr-4"></div>
          <span className="text-white/60 text-sm uppercase tracking-wider">Products</span>
        </div>

        <h2 className="text-4xl md:text-5xl font-bold mb-16">AI for all humanity</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <Card key={index} className="bg-black/20 border border-white/10 text-white overflow-hidden">
              <CardHeader>
                <CardTitle className="text-xl">{product.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-white/70 mb-6">{product.description}</CardDescription>
                {product.imageSrc && (
                  <div className="mt-4 relative h-48 w-full">
                    <Image
                      src={product.imageSrc}
                      alt={product.title}
                      fill
                      style={{ objectFit: "contain" }}
                      className="opacity-80"
                    />
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="border-white/30 hover:bg-white/10">
                  <a href={product.link} target="_blank" rel="noopener noreferrer">
                    {product.buttonText}
                    <svg className="ml-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <line x1="5" y1="12" x2="19" y2="12"></line>
                      <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                  </a>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
