"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import Image from "next/image";

const newsItems = [
  {
    title: "Grok 3 Beta — The Age of Reasoning Agents",
    summary: "We are thrilled to unveil an early preview of Grok 3, our most advanced model yet, blending superior reasoning with extensive pretraining knowledge.",
    date: "February 19, 2025",
    category: "grok",
    banner: "GROK 3",
    image: "https://ext.same-assets.com/292567494/1843355595.webp",
    link: "/news/grok-3"
  },
  {
    title: "xAI raises $6B Series C",
    summary: "We are partnering with A16Z, Blackrock, Fidelity Management & Research Company, Kingdom Holdings, Lightspeed, MGX, Morgan Stanley, OIA, QIA, Sequoia Capital, Valor Equity Partners and Vy Capital, amongst others.",
    date: "December 23, 2024",
    category: "company",
    banner: "SERIES C",
    image: "https://ext.same-assets.com/292567494/3588205437.webp",
    link: "/news/series-c"
  },
  {
    title: "Bringing Grok to Everyone",
    summary: "Grok is now faster, sharper, and has improved multilingual support. It is available to everyone on the platform.",
    date: "December 12, 2024",
    category: "grok",
    banner: "GROK FOR ALL",
    image: "https://ext.same-assets.com/292567494/150463674.webp",
    link: "/news/grok-1212"
  }
];

export default function LatestNews() {
  return (
    <section className="py-24 px-6 md:px-10 bg-black/50" id="news">
      <div className="container mx-auto">
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center">
            <div className="w-16 h-px bg-white/20 mr-4"></div>
            <span className="text-white/60 text-sm uppercase tracking-wider">Blog</span>
          </div>
          <Link href="/news" className="text-white/80 hover:text-white text-sm transition-colors">
            View all
          </Link>
        </div>

        <h2 className="text-4xl md:text-5xl font-bold mb-16">Latest news</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <div key={index} className="group">
              <Link href={item.link} className="block">
                <div className="relative mb-4 overflow-hidden rounded-lg aspect-square">
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    style={{ objectFit: "cover" }}
                    className="transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm px-3 py-1 rounded-md text-xs font-medium">
                    {item.banner}
                  </div>
                </div>
                <h3 className="text-xl font-medium mb-2">{item.title}</h3>
                <p className="text-white/70 text-sm mb-2 line-clamp-2">{item.summary}</p>
                <div className="flex items-center justify-between">
                  <span className="text-white/50 text-xs">{item.date}</span>
                  <Button variant="link" className="text-white p-0 h-auto">
                    <span className="text-sm">Read</span>
                  </Button>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
