"use client";

import { Button } from "@/components/ui/button";
import Image from "next/image";

export default function SuperGrokPromo() {
  return (
    <section className="bg-black py-16 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black to-[#1a1a1a] opacity-80" />

      <div className="container mx-auto px-6 md:px-10 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="md:flex-1">
            {/* SuperGrok Logo */}
            <div className="mb-6">
              <svg className="h-8" viewBox="0 0 120 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16.5 6.5c-3 0-5.5 2-6.3 4.7l-2-4.7H3v17h6V13.2C9 11.4 10.6 10 12.5 10s3.5 1.4 3.5 3.2V23.5h6V13.2c0-3.7-2.4-6.7-5.5-6.7z" fill="white" />
                <path d="M38 6.5C34 6.5 31 9.5 31 13.5s3 7 7 7 7-3 7-7-3-7-7-7zm0 10c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3zM59 6.5v2.8c-1-1.7-2.8-2.8-5-2.8-3.9 0-7 3.1-7 7s3.1 7 7 7c2.2 0 4-1.1 5-2.8v2.8h4V6.5h-4zm-4 10c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3zM72 9.5h-3V6.5h-4v3h-2v4h2v5c0 3 1.5 5 5.5 5H74v-4h-3c-.6 0-1-.4-1-1v-5h4v-4z" fill="white" />
                <path d="M90 12.2c0-3.7-2.4-6.7-5.5-6.7-3 0-5.5 2-6.3 4.7L76 6.5h-5v17h6V13.2c0-1.8 1.6-3.2 3.5-3.2s3.5 1.4 3.5 3.2v10.2h6V12.2zM106 12c-.9-3.4-4-5.5-7.5-5.5-4.1 0-7.5 3.4-7.5 7.5s3.4 7.5 7.5 7.5c3.5 0 6.6-2.1 7.5-5.5h-4.1c-.7 1-1.9 1.5-3.4 1.5-1.9 0-3.5-1.3-3.9-3h11.5c.1-.5.1-1 .1-1.5v-1h-4.2zm-8 0c.5-1.7 2-3 3.9-3 1.9 0 3.4 1.3 3.9 3h-7.8z" fill="white" />
                <path d="M120 6.5h-4l-5 6-5-6h-5l7.5 9-7.5 9h5l5-6 5 6h5l-7.5-9 7.5-9z" fill="white" />
              </svg>
            </div>

            <p className="text-xl text-white mb-8">
              Do more with Grok.<br />
              Unlock a SuperGrok subscription on Grok.com
            </p>

            <Button asChild className="bg-white hover:bg-white/90 text-black">
              <a href="https://grok.com/?show_subscribe=1" target="_blank" rel="noopener noreferrer">
                Sign up now
                <svg
                  className="ml-2 h-4 w-4"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
            </Button>
          </div>

          <div className="md:flex-1 flex justify-center md:justify-end">
            {/* Visualization graphic */}
            <div className="relative w-full max-w-xs md:max-w-md">
              <svg className="w-full" viewBox="0 0 400 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="20" y="20" width="360" height="120" rx="4" stroke="#4FA974" strokeWidth="2" />
                <path d="M20 40h360" stroke="#4FA974" strokeWidth="2" />
                <circle cx="36" cy="30" r="6" fill="#4FA974" />
                <circle cx="56" cy="30" r="6" fill="#4FA974" />
                <circle cx="76" cy="30" r="6" fill="#4FA974" />
                <path d="M50 80l50 50M150 70l-50 50M200 80l50 50M300 70l-50 50" stroke="#4FA974" strokeOpacity="0.6" strokeWidth="2" />
                <rect x="50" y="150" width="300" height="16" rx="8" fill="#333" />
                <rect x="50" y="150" width="220" height="16" rx="8" fill="#4FA974" />
                <text x="280" y="163" fill="white" fontSize="12" fontFamily="monospace">100% DONE</text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
