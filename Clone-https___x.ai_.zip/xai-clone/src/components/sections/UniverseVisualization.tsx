"use client";

import { useEffect, useRef, useState } from "react";

export default function UniverseVisualization() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Track window resize
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        const width = window.innerWidth;
        const height = 500; // Fixed height for visualization
        setDimensions({ width, height });
        canvasRef.current.width = width;
        canvasRef.current.height = height;
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Animation
  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Define stars
    const stars: {
      x: number;
      y: number;
      radius: number;
      vx: number;
      vy: number;
      brightness: number;
    }[] = [];

    // Create stars
    for (let i = 0; i < 150; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const radius = Math.random() * 1.5;
      const vx = (Math.random() - 0.5) * 0.3;
      const vy = (Math.random() - 0.5) * 0.3;
      const brightness = Math.random() * 0.8;

      stars.push({ x, y, radius, vx, vy, brightness });
    }

    // Center point
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Animation
    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw radial lines from center
      ctx.beginPath();
      for (let i = 0; i < 48; i++) {
        const angle = (i / 48) * Math.PI * 2;
        const length = Math.random() * 100 + 150;

        ctx.moveTo(centerX, centerY);
        ctx.lineTo(
          centerX + Math.cos(angle) * length,
          centerY + Math.sin(angle) * length
        );
      }
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.stroke();

      // Draw stars
      stars.forEach(star => {
        // Update position
        star.x += star.vx;
        star.y += star.vy;

        // Wrap around edges
        if (star.x < 0) star.x = canvas.width;
        if (star.x > canvas.width) star.x = 0;
        if (star.y < 0) star.y = canvas.height;
        if (star.y > canvas.height) star.y = 0;

        // Draw star
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${star.brightness})`;
        ctx.fill();
      });

      animationFrameId = window.requestAnimationFrame(render);
    };

    render();

    return () => {
      window.cancelAnimationFrame(animationFrameId);
    };
  }, [dimensions]);

  return (
    <div className="w-full bg-black relative overflow-hidden">
      <canvas
        ref={canvasRef}
        className="w-full"
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center space-y-10">
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-gray-300 opacity-70">
            Understand
          </h2>
          <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-gray-300 opacity-70">
            The Universe
          </h2>
        </div>
      </div>
    </div>
  );
}
