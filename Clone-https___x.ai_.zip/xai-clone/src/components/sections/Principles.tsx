"use client";

const principles = [
  {
    title: "Reasoning from First Principles",
    description: "We challenge conventional thinking by breaking down problems to their fundamental truths, grounded in logic."
  },
  {
    title: "No goal is too ambitious",
    description: "We embrace the most challenging obstacles by always pushing the limits of what's possible. We are motivated by what's unprecedented."
  },
  {
    title: "Move quickly and fix things",
    description: "Our approach to rapid development and iteration allows us to innovate at breakneck speeds. We're not interested in speed for speed's sake—we're here to solve real problems."
  }
];

export default function Principles() {
  return (
    <section className="py-24 px-6 md:px-10 bg-black/30" id="principles">
      <div className="container mx-auto">
        <div className="flex items-center mb-12">
          <div className="w-16 h-px bg-white/20 mr-4"></div>
          <span className="text-white/60 text-sm uppercase tracking-wider">Our principles</span>
        </div>

        <h2 className="text-4xl md:text-5xl font-bold mb-16">At our core</h2>

        <p className="text-xl md:text-2xl text-white/80 mb-16 max-w-2xl">
          We're a focused and mighty team connected by our curiosity, commitment, and unwavering drive.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {principles.map((principle, index) => (
            <div key={index} className="relative">
              <div className="mb-6">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="w-6 h-6"
                  >
                    {index === 0 ? (
                      // First principle icon - Reasoning
                      <path d="M9.25 12a.25.25 0 11-.5 0 .25.25 0 01.5 0zm-1.25 0a.25.25 0 11-.5 0 .25.25 0 01.5 0zm-1.25 0a.25.25 0 11-.5 0 .25.25 0 01.5 0z M12 4.5l-6.89 6.89c-.18.18-.29.43-.29.68v.17l.23 1.86c.02.14.09.27.19.36l1.3 1.3c.09.1.22.17.36.19l1.86.23c.25 0 .5-.11.68-.29L16.33 9M18 8l-2-6-6 2 8 4z" />
                    ) : index === 1 ? (
                      // Second principle icon - Ambitious
                      <path d="M12 2v20M17 5l-5-3-5 3M6 19l6 3 6-3" />
                    ) : (
                      // Third principle icon - Move quickly
                      <path d="M13 10V3L4 14h7v7l9-11h-7z" />
                    )}
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-4">{principle.title}</h3>
              <p className="text-white/70">{principle.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
