import type { Metadata } from "next";
import "./globals.css";
import ClientBody from "./ClientBody";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: "xAI - Understand the Universe",
  description: "xAI is an AI company with the mission of advancing scientific discovery and gaining a deeper understanding of our universe.",
  icons: {
    icon: "/x-favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>
        <ClientBody>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-grow">
              {children}
            </main>
            <Footer />
          </div>
        </ClientBody>
      </body>
    </html>
  );
}
