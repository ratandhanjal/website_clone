import Hero from "@/components/sections/Hero";
import Products from "@/components/sections/Products";
import LatestNews from "@/components/sections/LatestNews";
import Mission from "@/components/sections/Mission";
import Principles from "@/components/sections/Principles";
import UniverseVisualization from "@/components/sections/UniverseVisualization";
import SuperGrokPromo from "@/components/sections/SuperGrokPromo";

export default function Home() {
  return (
    <>
      <Hero />
      <UniverseVisualization />
      <Products />
      <Mission />
      <Principles />
      <SuperGrokPromo />
      <LatestNews />
    </>
  );
}
